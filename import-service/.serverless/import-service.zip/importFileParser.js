'use strict';
const AWS = require('aws-sdk');
const csv = require('csv-parser');


module.exports.importFileParser = async (event) => {
    const bucket = 'games-shop-aws-learning-uploads';
    const sqs = new AWS.SQS();
    const sns = new AWS.SNS();
    const s3 = new AWS.S3({ region: 'eu-west-1' });

    try {
        const queueUrl = await sqs.getQueueUrl({
            QueueName: 'catalogItemsQueue'
        }).promise();

        console.log('queueUrl', queueUrl);

        for await(const record of event.Records) {
            const s3Stream = s3.getObject({
                Bucket: bucket,
                Key: record.s3.object.key,
            }).createReadStream();

            const csvStream = s3Stream.pipe(csv());

            const products = [];

            for await (const line of streamToAsyncIterable(csvStream)) {
                products.push(line);
            }

            await sqs.sendMessage({
                QueueUrl: queueUrl.QueueUrl,
                MessageBody: JSON.stringify(products),
            }).promise();

            console.log(`CSV File from S3 Bucket: ${bucket}, Object key: ${record.s3.object.key}`);

            // const parsedData = await s3Stream.pipe(csv());
            // console.log('parsedData', parsedData);
            //
            // const sentMessage = await sqs.sendMessage({
            //     QueueUrl: queueUrl.QueueUrl,
            //     MessageBody: JSON.stringify(parsedData),
            // }).promise();

            // console.log(`Message sent to SQS with: ${sentMessage}`);

            console.log(`Copying from ${record.s3.bucket.name}/${record.s3.object.key}`);

            await s3.copyObject({
                Bucket: record.s3.bucket.name,
                CopySource: `${record.s3.bucket.name}/${record.s3.object.key}`,
                Key: record.s3.object.key.replace('uploaded', 'parsed'),
            }).promise();

            console.log(`Copied into ${record.s3.bucket.name}/${record.s3.object.key.replace('uploaded', 'parsed')}`);

            await s3.deleteObject({
                Bucket: record.s3.bucket.name,
                Key: record.s3.object.key,
            }).promise();

            const snsData = await sns.publish({
                TopicArn: 'arn:aws:sns:eu-west-1:216263405757:createProductTopic',
                Message: `Products were created`,
                Subject: 'New Products',
            }).promise();

            console.log("SNS message sent, messageId:", snsData.MessageId);

        }
    } catch (e) {
        console.error('importFileParser error:', e);
    }
};

function streamToAsyncIterable(stream) {
    const reader = stream[Symbol.asyncIterator] || stream[Symbol.iterator];
    return {
        [Symbol.asyncIterator]: reader.bind(stream)
    };
}
